using CourtSystemAPI.Configuration;

namespace CourtSystemAPI.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}