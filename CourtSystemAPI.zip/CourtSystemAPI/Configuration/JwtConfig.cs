namespace CourtSystemAPI.Configuration
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}